import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginService } from './services/login.service';
import { SuccesfulLoginComponent } from './succesful-login/succesful-login.component';
import { UserGuard } from './user.guard';

const routes: Routes = [
  { path: 'login',   component: LoginService },
  { path: 'success',   component: SuccesfulLoginComponent, canActivate: [UserGuard], },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
