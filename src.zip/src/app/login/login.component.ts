import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  constructor( private login:LoginService,private router:Router,private _snack:MatSnackBar) { }
 
  loginData={
    username:'',
    password:''
  }

  ngOnInit(): void {
  }

  formTest(){
    console.log("form submit"+this.loginData.username);
  }
  formSubmit(){
    
    if(this.loginData.username.trim()=='' || this.loginData.username==null){
       window.alert("username requ")
      return;
    } else if(this.loginData.password.trim()=='' || this.loginData.password==null){
      return;
     }


    //  this.login.generateToken(this.loginData).subscribe(
    //    (data:any)=>{
    //      console.log("Success");
    //      console.log(data);
    //    },
    //    (error)=>{
    //     console.log("error");
    //     console.log(error);
    //    }
    //  )


    
        // Request Server generate token
    this.login.generateToken(this.loginData).subscribe(
      (data: any)=>{
      
        this.loginData.username='';
        this.loginData.password='';
  
        //Login....
        this.login.loginUser(data.token);
        this.login.getCurrentUser().subscribe(
          (user:any)=>{
            this.login.setUser(user);
          
            //Redirect to admin dashboard
            if(this.login.getUserRole()=="ADMIN"){
              //Admin Dashboard
              // window.location.href='/admin';
              this.router.navigate(['admin'])
  
            }else if(this.login.getUserRole()=="NORMAL"){
              //User Dashboard
              this.router.navigate(['/success'])
            }else{
              this.login.logOut();
            }
  
            
          }
        )
      },(error)=>{
        this.loginData.username='';
        this.loginData.password='';
       this._snack.open('Invalid Data','Ok',{
         duration:3000
       })
        
        
      }
    )
  
    
  
  }
  
}
