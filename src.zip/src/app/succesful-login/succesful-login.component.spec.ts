import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccesfulLoginComponent } from './succesful-login.component';

describe('SuccesfulLoginComponent', () => {
  let component: SuccesfulLoginComponent;
  let fixture: ComponentFixture<SuccesfulLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuccesfulLoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuccesfulLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
