import { Component, OnInit } from '@angular/core';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-succesful-login',
  templateUrl: './succesful-login.component.html',
  styleUrls: ['./succesful-login.component.css']
})
export class SuccesfulLoginComponent implements OnInit {

  constructor(private login:LoginService) { }

  ngOnInit(): void {
  }

  logOut(){
    this.login.logOut();
    window.location.reload();
  }
}
